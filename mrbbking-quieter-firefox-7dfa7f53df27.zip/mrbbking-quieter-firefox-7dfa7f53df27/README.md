# Quieter Firefox

A project to make it easier to keep Firefox quiet during
webapp testing by disabling its background traffic

# Usage

Drop this user.js file in your Firefox profile directory
and restart Firefox.

Better yet, create a new profile for testing and put it there.

# Warning

This project is not concerned with "privacy" or "security" - 
some of these settings are actually bad for security.

Please don't use this with the profile you use for normal
web browsing. That would not be wise.


